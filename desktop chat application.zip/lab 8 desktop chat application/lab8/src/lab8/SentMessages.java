package lab8;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SentMessages extends JFrame {
    static String sender;
    public SentMessages(String sdr) {
        JFrame fr = new JFrame("Desktop Chat App-Inbox");
        fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JButton sendButton = new JButton("Send a message");
        JButton sentButton = new JButton("Inbox");
        JLabel label = new JLabel("");
        JLabel lbl = new JLabel("Messages you have sent");
        DefaultListModel<String> sentListModel = new DefaultListModel<>();
        JList<String> sentList = new JList<>(sentListModel);
        JScrollPane sentScrollPane = new JScrollPane(sentList);
        int rowCount = 0;
        sender = sdr;
        try { Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(SignUpForm.class.getName()).log(Level.SEVERE, null, ex);
        }
        String jdbcUrl = "jdbc:mysql://localhost:3306/lab8";
        String usernameDB = "root";
        String passwordDB = "root123";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, usernameDB, passwordDB)) {
            String sql = "SELECT count(*) as messageCount from messages where sender = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, sender);
                ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                        rowCount = resultSet.getInt("messageCount");
                }
            }
        String recipient;
        String msg;
        sql = "SELECT recipient, message from messages where sender = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, sender);
                ResultSet resultSet = statement.executeQuery();
            if (rowCount > 0){
                while (resultSet.next()) {
                recipient = resultSet.getString("recipient");
                msg = resultSet.getString("message");
                sentListModel.addElement(recipient + ": " + msg);}
            }
            else {
                sentListModel.addElement("No messages");
            }}
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error: Unable to connect to the database.");
        }
        sendButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                send s = new send(sender);
                s.setVisible(true);
                fr.setVisible(false);
            }
        });
        sentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ChatApp ca = new ChatApp(sender);
                ca.setVisible(true);
                fr.setVisible(false);               
            }
        });
        JPanel panel = new JPanel();
        panel.setBackground(Color.white);
        panel.setLayout(new GridLayout(2, 1));
        JPanel panel1 = new JPanel();
        panel1.setBackground(Color.white);
        panel1.setLayout(new GridLayout(1, 3));
        panel1.add(sentButton);
        panel1.add(label);
        panel1.add(sendButton);
        panel.add(panel1);
        panel.add(lbl);
        fr.add(panel, BorderLayout.NORTH);
        fr.add(sentScrollPane, BorderLayout.CENTER);
        fr.pack();
        fr.setSize(500,400);
        fr.setResizable(false);
        fr.setLocationRelativeTo(null);
        fr.setVisible(true);
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SentMessages(sender));
    }
}