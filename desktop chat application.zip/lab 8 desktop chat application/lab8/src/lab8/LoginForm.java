package lab8;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LoginForm extends JFrame{
    public String username;
    private JTextField usernameField;
    private JPasswordField passwordField;
    public LoginForm() {
        JFrame fr = new JFrame("Login");
        fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JLabel usernameLabel = new JLabel(" Username:");
        usernameField = new JTextField();
        JLabel passwordLabel = new JLabel(" Password:");
        passwordField = new JPasswordField();
        JButton loginButton = new JButton("Login");
        JLabel label = new JLabel("");
        JLabel signupLabel = new JLabel(" Don't have an account, Sign Up?");
        JButton signupButton = new JButton("Sign Up");
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login(fr);  
            }
        });
        signupButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SignUpForm su = new SignUpForm();
                su.setVisible(true);
                fr.setVisible(false);                
            }
        });
        JPanel panel = new JPanel();
        panel.setBackground(Color.white);
        panel.setLayout(new GridLayout(2, 2));
        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        fr.add(panel);
        JPanel panel2 = new JPanel();
        panel2.setBackground(Color.white);
        panel2.setLayout(new GridLayout(4, 1));
        panel2.add(loginButton);
        panel2.add(label);
        panel2.add(signupLabel);
        panel2.add(signupButton);
        fr.add(panel2, BorderLayout.SOUTH);
        fr.pack();
        fr.setSize(400,190);
        fr.setResizable(false);
        fr.setLocationRelativeTo(null);
        fr.setVisible(true);
    }
    private void login(JFrame fr) {
        username = usernameField.getText();
        char[] passwordChars = passwordField.getPassword();
        String password = new String(passwordChars);
        try { Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(SignUpForm.class.getName()).log(Level.SEVERE, null, ex);
        }
        String jdbcUrl = "jdbc:mysql://localhost:3306/lab8";
        String usernameDB = "root";
        String passwordDB = "root123";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, usernameDB, passwordDB)) {
            String sql = "SELECT * FROM users WHERE username = ? AND password = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, username);
                statement.setString(2, password);
                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    JOptionPane.showMessageDialog(null, "Login successful!");
                    ChatApp ca = new ChatApp(username);
                    ca.setVisible(true);
                    fr.setVisible(false); 
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid username or password.");
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error: Unable to connect to the database.");
        }
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginForm());
    }
}