package lab8;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class SignUpForm extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JPasswordField password2Field;
    private JLabel pwLabel;
    private JTextField emailField;
    private JTextField phoneField;
    public SignUpForm() {
        JFrame fr = new JFrame("Sign Up");
        fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JLabel usernameLabel = new JLabel(" Username:");
        usernameField = new JTextField();
        JLabel passwordLabel = new JLabel(" Password:");
        passwordField = new JPasswordField();
        JLabel password2Label = new JLabel(" Confirm Password:");
        password2Field = new JPasswordField();
        JLabel pwLabel = new JLabel(" Enter same password");
        JLabel pw2Label = new JLabel("");
        JLabel emailLabel = new JLabel(" Email:");
        emailField = new JTextField();
        JLabel phoneLabel = new JLabel(" Phone No.:");
        phoneField = new JTextField();
        JButton signUpButton = new JButton("Sign Up");
        JLabel label = new JLabel("");
        JLabel loginLabel = new JLabel("Already have an account?");
        JButton loginButton = new JButton("Login");
        signUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                signUp(fr);                  
            }
        });
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                LoginForm lg = new LoginForm();
                lg.setVisible(true);
                fr.setVisible(false);                
            }
        });
        DocumentListener dl = new DocumentListener(){
            @Override
            public void insertUpdate(DocumentEvent e) {
                changeColor(pwLabel);               
            }
            @Override
            public void removeUpdate(DocumentEvent e) {
                changeColor(pwLabel);               
            }
            @Override
            public void changedUpdate(DocumentEvent e) {
                changeColor(pwLabel);               
            }
        };
        passwordField.getDocument().addDocumentListener(dl);
        password2Field.getDocument().addDocumentListener(dl);
        JPanel panel = new JPanel();
        panel.setBackground(Color.white);
        panel.setLayout(new GridLayout(6, 2));
        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(password2Label);
        panel.add(password2Field);
        panel.add(pwLabel);
        panel.add(pw2Label);
        panel.add(emailLabel);
        panel.add(emailField);
        panel.add(phoneLabel);
        panel.add(phoneField);
        JPanel panel2 = new JPanel();
        panel2.setBackground(Color.white);
        panel2.setLayout(new GridLayout(4, 1));
        panel2.add(signUpButton);
        panel2.add(label);
        panel2.add(loginLabel, BorderLayout.CENTER);
        panel2.add(loginButton);
        fr.add(panel);
        fr.add(panel2, BorderLayout.SOUTH);
        fr.pack();
        fr.setSize(400,250);
        fr.setResizable(false);
        fr.setLocationRelativeTo(null);
        fr.setVisible(true);
    }
    private void signUp(JFrame fr) {
        String username = usernameField.getText();
        char[] passwordChars = passwordField.getPassword();
        String email = emailField.getText();
        String phone = phoneField.getText();
        String password = new String(passwordChars);
        try { Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(SignUpForm.class.getName()).log(Level.SEVERE, null, ex);
        }
        String jdbcUrl = "jdbc:mysql://localhost:3306/lab8";
        String usernameDB = "root";
        String passwordDB = "root123";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, usernameDB, passwordDB)) {
            String sql = "INSERT INTO users (username, password, email, phone) VALUES (?,?,?,?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, username);
                statement.setString(2, password);
                statement.setString(3, email);
                statement.setString(4, phone);
                statement.executeUpdate();
                JOptionPane.showMessageDialog(null, "Account created successfully!");
                LoginForm lg = new LoginForm();
                lg.setVisible(true);
                fr.setVisible(false);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error: Unable to create account.");
        }
    }
    private void changeColor(JLabel lbl) {
        if (passwordField.getPassword().length == 0 || password2Field.getPassword().length == 0){
            lbl.setText(" Enter same password");
            lbl.setForeground(Color.GREEN);}
        else if (Arrays.equals(passwordField.getPassword(), password2Field.getPassword())){
            lbl.setText(" Enter same password");
            lbl.setForeground(Color.GREEN);}
        else{
            lbl.setText(" Enter same password");
            lbl.setForeground(Color.RED);}
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SignUpForm());
    }
}