package lab8;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ChatApp extends JFrame {
    static String recipient;
    public ChatApp(String rec) {
        JFrame fr = new JFrame("Desktop Chat App-Inbox");
        fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JButton sendButton = new JButton("Send a message");
        JButton sentButton = new JButton("Sent messages");
        JLabel label = new JLabel("");
        JLabel lbl = new JLabel("Messages you have recieived");
        DefaultListModel<String> inboxListModel = new DefaultListModel<>();
        JList<String> inboxList = new JList<>(inboxListModel);
        JScrollPane inboxScrollPane = new JScrollPane(inboxList);
        int rowCount = 0;
        recipient = rec;
        try { Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(SignUpForm.class.getName()).log(Level.SEVERE, null, ex);
        }
        String jdbcUrl = "jdbc:mysql://localhost:3306/lab8";
        String usernameDB = "root";
        String passwordDB = "root123";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, usernameDB, passwordDB)) {
            String sql = "SELECT count(*) as messageCount from messages where recipient = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, recipient);
                ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                        rowCount = resultSet.getInt("messageCount");
                }
            }
        String sender;
        String msg;
        sql = "SELECT sender, message from messages where recipient = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, recipient);
                ResultSet resultSet = statement.executeQuery();
            if (rowCount > 0){
            while (resultSet.next()) {
                sender = resultSet.getString("sender");
                msg = resultSet.getString("message");
                inboxListModel.addElement(sender + ": " + msg);}
            }
            else {
                inboxListModel.addElement("No messages");
            }}
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error: Unable to connect to the database.");
        }
        sendButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                send s = new send(recipient);
                s.setVisible(true);
                fr.setVisible(false);
            }
        });
        sentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SentMessages sm = new SentMessages(recipient);
                sm.setVisible(true);
                fr.setVisible(false);               
            }
        });
        JPanel panel = new JPanel();
        panel.setBackground(Color.white);
        panel.setLayout(new GridLayout(2, 1));
        JPanel panel1 = new JPanel();
        panel1.setBackground(Color.white);
        panel1.setLayout(new GridLayout(1, 3));
        panel1.add(sentButton);
        panel1.add(label);
        panel1.add(sendButton);
        panel.add(panel1);
        panel.add(lbl);
        fr.add(panel, BorderLayout.NORTH);
        fr.add(inboxScrollPane, BorderLayout.CENTER);
        fr.pack();
        fr.setSize(500,400);
        fr.setResizable(false);
        fr.setLocationRelativeTo(null);
        fr.setVisible(true);
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ChatApp(recipient));
    }
}